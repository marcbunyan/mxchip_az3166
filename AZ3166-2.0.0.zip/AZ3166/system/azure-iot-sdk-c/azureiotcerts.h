// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef AZUREIOTCERTS_H
#define AZUREIOTCERTS_H

#warning "azureiotcerts.h is obsoleted, please include certs/certs.h"

#include "certs/certs.h"

#endif /* AZUREIOTCERTS_H */
