# Example: WebSocket Client

This is an Hello World project demonstrating WebSocket connecting via Wi-Fi.

## Release Notes

### Mar 2018